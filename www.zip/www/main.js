(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0negksux.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0negksux.entry.js",
		0,
		"common",
		128
	],
	"./0negksux.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0negksux.sc.entry.js",
		0,
		"common",
		129
	],
	"./0tqlwsdt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0tqlwsdt.entry.js",
		0,
		"common",
		130
	],
	"./0tqlwsdt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0tqlwsdt.sc.entry.js",
		0,
		"common",
		131
	],
	"./5esrbynz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5esrbynz.entry.js",
		"common",
		102
	],
	"./5esrbynz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5esrbynz.sc.entry.js",
		"common",
		103
	],
	"./5ptcnpes.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ptcnpes.entry.js",
		"common",
		10
	],
	"./5ptcnpes.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ptcnpes.sc.entry.js",
		"common",
		11
	],
	"./5pwuvxkr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5pwuvxkr.entry.js",
		"common",
		54
	],
	"./5pwuvxkr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5pwuvxkr.sc.entry.js",
		"common",
		55
	],
	"./5vxaf0jn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5vxaf0jn.entry.js",
		"common",
		56
	],
	"./5vxaf0jn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5vxaf0jn.sc.entry.js",
		"common",
		57
	],
	"./5y1t3u06.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5y1t3u06.entry.js",
		0,
		"common",
		132
	],
	"./5y1t3u06.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5y1t3u06.sc.entry.js",
		0,
		"common",
		133
	],
	"./6kgso7pq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.entry.js",
		"common",
		12
	],
	"./6kgso7pq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.sc.entry.js",
		"common",
		13
	],
	"./760enb6s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/760enb6s.entry.js",
		"common",
		14
	],
	"./760enb6s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/760enb6s.sc.entry.js",
		"common",
		15
	],
	"./7mjltlqo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7mjltlqo.entry.js",
		"common",
		16
	],
	"./7mjltlqo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7mjltlqo.sc.entry.js",
		"common",
		17
	],
	"./admmxern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.entry.js",
		"common",
		58
	],
	"./admmxern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.sc.entry.js",
		"common",
		59
	],
	"./apfh3flu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/apfh3flu.entry.js",
		"common",
		18
	],
	"./apfh3flu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/apfh3flu.sc.entry.js",
		"common",
		19
	],
	"./b3nyp0te.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b3nyp0te.entry.js",
		"common",
		104
	],
	"./b3nyp0te.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b3nyp0te.sc.entry.js",
		"common",
		105
	],
	"./b8qia1ip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b8qia1ip.entry.js",
		"common",
		106
	],
	"./b8qia1ip.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b8qia1ip.sc.entry.js",
		"common",
		107
	],
	"./bngjpe45.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bngjpe45.entry.js",
		"common",
		20
	],
	"./bngjpe45.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bngjpe45.sc.entry.js",
		"common",
		21
	],
	"./czp4dy0u.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/czp4dy0u.entry.js",
		0,
		"common",
		136
	],
	"./czp4dy0u.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/czp4dy0u.sc.entry.js",
		0,
		"common",
		137
	],
	"./d4uqnmsi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d4uqnmsi.entry.js",
		2,
		"common",
		138
	],
	"./d4uqnmsi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d4uqnmsi.sc.entry.js",
		2,
		"common",
		139
	],
	"./dq0i6hqg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dq0i6hqg.entry.js",
		"common",
		94
	],
	"./dq0i6hqg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dq0i6hqg.sc.entry.js",
		"common",
		95
	],
	"./dsb5jv5r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsb5jv5r.entry.js",
		"common",
		22
	],
	"./dsb5jv5r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dsb5jv5r.sc.entry.js",
		"common",
		23
	],
	"./ejapjnva.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejapjnva.entry.js",
		"common",
		60
	],
	"./ejapjnva.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejapjnva.sc.entry.js",
		"common",
		61
	],
	"./emuc9tqd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/emuc9tqd.entry.js",
		"common",
		24
	],
	"./emuc9tqd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/emuc9tqd.sc.entry.js",
		"common",
		25
	],
	"./f4ov2fgy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f4ov2fgy.entry.js",
		"common",
		62
	],
	"./f4ov2fgy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f4ov2fgy.sc.entry.js",
		"common",
		63
	],
	"./fkzdmlip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.entry.js",
		140
	],
	"./fkzdmlip.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.sc.entry.js",
		141
	],
	"./ftij5hee.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ftij5hee.entry.js",
		0,
		"common",
		108
	],
	"./ftij5hee.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ftij5hee.sc.entry.js",
		0,
		"common",
		109
	],
	"./fwzyk2t9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fwzyk2t9.entry.js",
		"common",
		26
	],
	"./fwzyk2t9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fwzyk2t9.sc.entry.js",
		"common",
		27
	],
	"./gbcxupo7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gbcxupo7.entry.js",
		"common",
		64
	],
	"./gbcxupo7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gbcxupo7.sc.entry.js",
		"common",
		65
	],
	"./ggbyzsii.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ggbyzsii.entry.js",
		0,
		"common",
		142
	],
	"./ggbyzsii.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ggbyzsii.sc.entry.js",
		0,
		"common",
		143
	],
	"./he63oefa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/he63oefa.entry.js",
		"common",
		96
	],
	"./he63oefa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/he63oefa.sc.entry.js",
		"common",
		97
	],
	"./helxzsef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.entry.js",
		144
	],
	"./helxzsef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.sc.entry.js",
		145
	],
	"./hg9mfbbd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hg9mfbbd.entry.js",
		"common",
		66
	],
	"./hg9mfbbd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hg9mfbbd.sc.entry.js",
		"common",
		67
	],
	"./htwkhopr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/htwkhopr.entry.js",
		"common",
		98
	],
	"./htwkhopr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/htwkhopr.sc.entry.js",
		"common",
		99
	],
	"./hxnvegpa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hxnvegpa.entry.js",
		0,
		"common",
		146
	],
	"./hxnvegpa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hxnvegpa.sc.entry.js",
		0,
		"common",
		147
	],
	"./i4lkxzhp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i4lkxzhp.entry.js",
		0,
		"common",
		148
	],
	"./i4lkxzhp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i4lkxzhp.sc.entry.js",
		0,
		"common",
		149
	],
	"./i5bu78vq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.entry.js",
		"common",
		68
	],
	"./i5bu78vq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.sc.entry.js",
		"common",
		69
	],
	"./ibsc94yw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ibsc94yw.entry.js",
		"common",
		110
	],
	"./ibsc94yw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ibsc94yw.sc.entry.js",
		"common",
		111
	],
	"./iqlhkurd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.entry.js",
		"common",
		70
	],
	"./iqlhkurd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.sc.entry.js",
		"common",
		71
	],
	"./isuxxasv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.entry.js",
		"common",
		72
	],
	"./isuxxasv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.sc.entry.js",
		"common",
		73
	],
	"./j241fzpw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j241fzpw.entry.js",
		"common",
		28
	],
	"./j241fzpw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j241fzpw.sc.entry.js",
		"common",
		29
	],
	"./j9sczdb9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9sczdb9.entry.js",
		"common",
		30
	],
	"./j9sczdb9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j9sczdb9.sc.entry.js",
		"common",
		31
	],
	"./jpkvsu5y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.entry.js",
		"common",
		114
	],
	"./jpkvsu5y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.sc.entry.js",
		"common",
		115
	],
	"./jtlohgvo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtlohgvo.entry.js",
		"common",
		32
	],
	"./jtlohgvo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtlohgvo.sc.entry.js",
		"common",
		33
	],
	"./k4hoilf4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k4hoilf4.entry.js",
		"common",
		74
	],
	"./k4hoilf4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k4hoilf4.sc.entry.js",
		"common",
		75
	],
	"./ksgex3rj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksgex3rj.entry.js",
		"common",
		34
	],
	"./ksgex3rj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksgex3rj.sc.entry.js",
		"common",
		35
	],
	"./mdhtqfpy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mdhtqfpy.entry.js",
		0,
		"common",
		150
	],
	"./mdhtqfpy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mdhtqfpy.sc.entry.js",
		0,
		"common",
		151
	],
	"./mri9bdlj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.entry.js",
		152
	],
	"./mri9bdlj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.sc.entry.js",
		153
	],
	"./ni878jk5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ni878jk5.entry.js",
		0,
		"common",
		154
	],
	"./ni878jk5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ni878jk5.sc.entry.js",
		0,
		"common",
		155
	],
	"./o6zsuoqi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6zsuoqi.entry.js",
		"common",
		76
	],
	"./o6zsuoqi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6zsuoqi.sc.entry.js",
		"common",
		77
	],
	"./oiqlagn3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiqlagn3.entry.js",
		"common",
		78
	],
	"./oiqlagn3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiqlagn3.sc.entry.js",
		"common",
		79
	],
	"./okzvvz1s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okzvvz1s.entry.js",
		"common",
		36
	],
	"./okzvvz1s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/okzvvz1s.sc.entry.js",
		"common",
		37
	],
	"./p49hrwqk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/p49hrwqk.entry.js",
		0,
		"common",
		112
	],
	"./p49hrwqk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/p49hrwqk.sc.entry.js",
		0,
		"common",
		113
	],
	"./q3pkc1ix.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/q3pkc1ix.entry.js",
		"common",
		116
	],
	"./q3pkc1ix.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/q3pkc1ix.sc.entry.js",
		"common",
		117
	],
	"./qjwxr7dv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qjwxr7dv.entry.js",
		"common",
		38
	],
	"./qjwxr7dv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qjwxr7dv.sc.entry.js",
		"common",
		39
	],
	"./qqusykhh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qqusykhh.entry.js",
		"common",
		80
	],
	"./qqusykhh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qqusykhh.sc.entry.js",
		"common",
		81
	],
	"./rkecsmgc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.entry.js",
		"common",
		118
	],
	"./rkecsmgc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.sc.entry.js",
		"common",
		119
	],
	"./rrpxfm2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.entry.js",
		156
	],
	"./rrpxfm2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.sc.entry.js",
		157
	],
	"./rtzpmome.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rtzpmome.entry.js",
		"common",
		40
	],
	"./rtzpmome.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rtzpmome.sc.entry.js",
		"common",
		41
	],
	"./tlbladaf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.entry.js",
		"common",
		42
	],
	"./tlbladaf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.sc.entry.js",
		"common",
		43
	],
	"./tlg9i3ly.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlg9i3ly.entry.js",
		"common",
		100
	],
	"./tlg9i3ly.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlg9i3ly.sc.entry.js",
		"common",
		101
	],
	"./txpe5bol.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/txpe5bol.entry.js",
		"common",
		82
	],
	"./txpe5bol.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/txpe5bol.sc.entry.js",
		"common",
		83
	],
	"./uwkxwzih.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uwkxwzih.entry.js",
		"common",
		44
	],
	"./uwkxwzih.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uwkxwzih.sc.entry.js",
		"common",
		45
	],
	"./vb7zan3s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vb7zan3s.entry.js",
		"common",
		84
	],
	"./vb7zan3s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vb7zan3s.sc.entry.js",
		"common",
		85
	],
	"./vhwyavqm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vhwyavqm.entry.js",
		"common",
		46
	],
	"./vhwyavqm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vhwyavqm.sc.entry.js",
		"common",
		47
	],
	"./vl7mbywk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vl7mbywk.entry.js",
		0,
		"common",
		158
	],
	"./vl7mbywk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vl7mbywk.sc.entry.js",
		0,
		"common",
		159
	],
	"./vxahkmyw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vxahkmyw.entry.js",
		"common",
		48
	],
	"./vxahkmyw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vxahkmyw.sc.entry.js",
		"common",
		49
	],
	"./w7d82ebh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/w7d82ebh.entry.js",
		0,
		"common",
		160
	],
	"./w7d82ebh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/w7d82ebh.sc.entry.js",
		0,
		"common",
		161
	],
	"./wbj4wz5k.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wbj4wz5k.entry.js",
		2,
		"common",
		162
	],
	"./wbj4wz5k.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wbj4wz5k.sc.entry.js",
		2,
		"common",
		163
	],
	"./wjdsdnuu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.entry.js",
		"common",
		86
	],
	"./wjdsdnuu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.sc.entry.js",
		"common",
		87
	],
	"./wjpkaasy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjpkaasy.entry.js",
		"common",
		50
	],
	"./wjpkaasy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjpkaasy.sc.entry.js",
		"common",
		51
	],
	"./wrbebrfs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrbebrfs.entry.js",
		"common",
		120
	],
	"./wrbebrfs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrbebrfs.sc.entry.js",
		"common",
		121
	],
	"./xar48p4b.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xar48p4b.entry.js",
		"common",
		122
	],
	"./xar48p4b.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xar48p4b.sc.entry.js",
		"common",
		123
	],
	"./xo7dncgt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xo7dncgt.entry.js",
		"common",
		88
	],
	"./xo7dncgt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xo7dncgt.sc.entry.js",
		"common",
		89
	],
	"./ygdst8ix.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygdst8ix.entry.js",
		"common",
		90
	],
	"./ygdst8ix.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygdst8ix.sc.entry.js",
		"common",
		91
	],
	"./yxoiyuhs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxoiyuhs.entry.js",
		"common",
		92
	],
	"./yxoiyuhs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yxoiyuhs.sc.entry.js",
		"common",
		93
	],
	"./zfajadxx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfajadxx.entry.js",
		"common",
		124
	],
	"./zfajadxx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfajadxx.sc.entry.js",
		"common",
		125
	],
	"./ziv0mko0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.entry.js",
		"common",
		126
	],
	"./ziv0mko0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ziv0mko0.sc.entry.js",
		"common",
		127
	],
	"./zr4o4ivv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zr4o4ivv.entry.js",
		0,
		"common",
		164
	],
	"./zr4o4ivv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zr4o4ivv.sc.entry.js",
		0,
		"common",
		165
	],
	"./zxlnzjcg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zxlnzjcg.entry.js",
		"common",
		52
	],
	"./zxlnzjcg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zxlnzjcg.sc.entry.js",
		"common",
		53
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', loadChildren: './home/home.module#HomePageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\r\n  <ion-router-outlet></ion-router-outlet>\r\n</ion-app>\r\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");





var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            //this.statusBar.styleDefault();
            _this.statusBar.styleLightContent();
            _this.splashScreen.hide();
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/insomnia/ngx */ "./node_modules/@ionic-native/insomnia/ngx/index.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");
/* harmony import */ var _barcode_barcode_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./barcode/barcode.component */ "./src/app/barcode/barcode.component.ts");












var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], _barcode_barcode_component__WEBPACK_IMPORTED_MODULE_11__["BarcodeComponent"]],
            entryComponents: [],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"]],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
                _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_9__["Insomnia"],
                _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_10__["BarcodeScanner"]
            ],
            bootstrap: [_barcode_barcode_component__WEBPACK_IMPORTED_MODULE_11__["BarcodeComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/barcode/barcode.component.html":
/*!************************************************!*\
  !*** ./src/app/barcode/barcode.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n    <ion-header>\n      <ion-toolbar>\n        <ion-title>Ionic Barcode Scanner</ion-title>\n      </ion-toolbar>\n    </ion-header>\n  \n    <ion-content padding>\n        <ion-button (click)=\"encode()\">Encode</ion-button><br/><br/>\n        <ion-button (click)=\"scan()\">Scan</ion-button>\n    </ion-content>\n  <ion-footer>\n      <ion-toolbar>\n        <ion-title>Footer</ion-title>\n      </ion-toolbar>\n    </ion-footer>\n  </ion-app>"

/***/ }),

/***/ "./src/app/barcode/barcode.component.scss":
/*!************************************************!*\
  !*** ./src/app/barcode/barcode.component.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2JhcmNvZGUvYmFyY29kZS5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/barcode/barcode.component.ts":
/*!**********************************************!*\
  !*** ./src/app/barcode/barcode.component.ts ***!
  \**********************************************/
/*! exports provided: BarcodeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BarcodeComponent", function() { return BarcodeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");



var BarcodeComponent = /** @class */ (function () {
    function BarcodeComponent(barcode) {
        this.barcode = barcode;
    }
    BarcodeComponent.prototype.encode = function () {
        var textToEncode = window.prompt("Enter text to encode");
        this.barcode.encode(this.barcode.Encode.TEXT_TYPE, textToEncode).then(function (data) {
            alert(JSON.stringify(data));
        }, function (err) {
            alert(JSON.stringify(err));
        });
    };
    BarcodeComponent.prototype.scan = function () {
        this.barcode.scan().then(function (barcodeData) {
            alert(barcodeData.text);
        }, function (err) {
            alert(JSON.stringify(err));
        });
    };
    BarcodeComponent.prototype.ngOnInit = function () { };
    BarcodeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-barcode',
            template: __webpack_require__(/*! ./barcode.component.html */ "./src/app/barcode/barcode.component.html"),
            styles: [__webpack_require__(/*! ./barcode.component.scss */ "./src/app/barcode/barcode.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__["BarcodeScanner"]])
    ], BarcodeComponent);
    return BarcodeComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Projects\Ionic Projects\ionic\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map